CurrentPath=$(pwd)
echo $CurrentPath
cd $CurrentPath/build/
cmake -DCMAKE_BUILD_TYPE=Debug ../src
make -j8